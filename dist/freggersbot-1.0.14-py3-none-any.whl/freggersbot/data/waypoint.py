class Waypoint:
	
	def __init__(self, position, duration):
		self.position = position
		self.duration = duration